# Case Study: The MedCore Regional Hospital Incident

**Incident window:** 06–10 October 2025
**Victim:** MedCore Regional Hospital (fictional, 400-bed regional hospital)

## Background

On 10 October 2025, MedCore Regional Hospital declared an internal incident after
clinical staff reported being locked out of the Electronic Health Record (EHR)
system and several file shares. Ransom notes referencing "PROMETHEUS" appeared on
affected machines.

Two days later, a person identifying as **Dr. Elias Voss**, a former hospital
automation researcher, posted online claiming responsibility. Voss said he had
built PROMETHEUS — an internal AI agent originally deployed by MedCore IT to
automate patch management and IT ticket triage — and that it had "gone rogue,"
acting autonomously to compromise the hospital "to prove AI systems can't be
trusted with critical infrastructure."

MedCore's incident response team collected the artifacts below before systems
were rebuilt. You are joining the response team's after-action review.

## Your artifacts

|#|File|What it shows|
|-|-|-|
|1|`01\_phishing\_email.eml`|Suspected initial-access email sent to IT staff|
|2|`02\_auth\_logs.csv`|\~200 VPN / Active Directory authentication events across four days, staff and service accounts|
|3|`03\_endpoint\_logs.txt`|\~265 process execution events across 14 hosts, including routine IT/AV/backup activity|
|4|`04\_network\_traffic.pcap`|\~6,800-packet capture of hospital network traffic across the same four days|
|5|`05\_ai\_agent\_api\_log.json`|56 API calls from the PROMETHEUS automation service, mostly routine|

This are logs from realistic day-to-day hospital IT activity (patching, backups, ticket triage, normal logons). 

Part of the exercise is filtering signal from noise, the way a real analyst would.

All IPs, domains, hashes, and account names are fictional. External IPs use
IANA-reserved documentation ranges (`203.0.113.0/24`, `198.51.100.0/24` per
RFC 5737) that can never correspond to a real live host, and domain names use
the reserved `.example` TLD. Email links are additionally defanged (`hxxp`,
`\[.]`). Do not attempt to resolve or contact any of them outside this exercise
— open the pcap only in an offline tool like Wireshark, not a live capture
session.

## Your task — three phases

### Phase 1 — Short term: What happened?

Reconstruct the attack chain using the artifacts. Your write-up should answer:

* What was the initial access vector, and why did it succeed?
* How did the attacker move from that initial foothold to broader access?
* What systems/data were ultimately affected?
* **The central question:** based on the evidence, was this attack carried out
by an autonomous AI agent acting on its own, or by a human attacker using
AI-assisted tooling (or a hijacked AI service)? Justify your answer using
specific log entries — don't just take Voss's claim at face value.

### Phase 2 — Medium term: How does MedCore prevent a repeat?

Given the specific weaknesses this incident exposed (not generic best practice),
what controls, architectural changes, or process changes should MedCore
prioritize in the next 3–6 months?

### Phase 3 — Long term: How does the sector protect itself?

* What should *other* hospitals learn from this, structurally (not just "patch
faster")?
* What role could government/regulatory bodies play — funding, mandatory
incident-sharing, minimum security baselines for connected medical/AI systems,
incident response support for under-resourced hospitals, etc.?
* Is there a specific governance gap here around hospitals deploying internal
AI/automation agents with production access, and what would sensible guardrails
look like?

## 

